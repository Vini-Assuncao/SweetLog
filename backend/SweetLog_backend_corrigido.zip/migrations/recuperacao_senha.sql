USE sweetlog;

CREATE TABLE IF NOT EXISTS tbl_recuperacao_senha (
    id_recuperacao BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    numero_matricula INT NOT NULL,
    codigo_hash VARCHAR(255) NOT NULL,
    token_hash CHAR(64) NULL,
    tentativas TINYINT UNSIGNED NOT NULL DEFAULT 0,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expira_em DATETIME NOT NULL,
    verificado_em DATETIME NULL,
    usado_em DATETIME NULL,
    INDEX idx_recuperacao_funcionario_status (numero_matricula, usado_em, expira_em),
    CONSTRAINT fk_recuperacao_funcionario
        FOREIGN KEY (numero_matricula)
        REFERENCES tbl_funcionarios(numero_matricula)
        ON DELETE CASCADE
);
